

let image=document.createElement("img");
    document.querySelector(".imageContainer").append(image);
  
    let i=0;
    slider(i);
    function slider(el){
        setInterval(function(){
            if(el<newarr.length){
                image.src=newarr[el];
                el++;
            }
            if(el==newarr.length){
                el=0;
            }
        },2000);
    }

  

    




$(".slider").each(function () {
    var $this = $(this);
    var $group = $this.find(".slide_group");
    var $slides = $this.find(".slide");
    var bulletArray = [];
    var currentIndex = 0;
    var timeout;
  
    function move(newIndex) {
      var animateLeft, slideLeft;
  
      advance();
  
      if ($group.is(":animated") || currentIndex === newIndex) {
        return;
      }
  
      bulletArray[currentIndex].removeClass("active");
      bulletArray[newIndex].addClass("active");
  
      if (newIndex > currentIndex) {
        slideLeft = "100%";
        animateLeft = "-100%";
      } else {
        slideLeft = "-100%";
        animateLeft = "100%";
      }
  
      $slides.eq(newIndex).css({
        display: "block",
        left: slideLeft
      });
      $group.animate(
        {
          left: animateLeft
        },
        function () {
          $slides.eq(currentIndex).css({
            display: "none"
          });
          $slides.eq(newIndex).css({
            left: 0
          });
          $group.css({
            left: 0
          });
          currentIndex = newIndex;
        }
      );
    }
  
    function advance() {
      clearTimeout(timeout);
      timeout = setTimeout(function () {
        if (currentIndex < $slides.length - 1) {
          move(currentIndex + 1);
        } else {
          move(0);
        }
      }, 4000);
    }
  
    $(".next_btn").on("click", function () {
      if (currentIndex < $slides.length - 1) {
        move(currentIndex + 1);
      } else {
        move(0);
      }
    });
  
    $(".previous_btn").on("click", function () {
      if (currentIndex !== 0) {
        move(currentIndex - 1);
      } else {
        move(3);
      }
    });
  
    $.each($slides, function (index) {
    var $button = $('<a class="slide_btn">&bull;</a>');
  
      if (index === currentIndex) {
        $button.addClass("active");
      }
      $button
        .on("click", function () {
          move(index);
        })
        // .appendTo(".slide_buttons");
      bulletArray.push($button);
    });
  
    advance();
  });
//   Lazy Girl's Bff's card
  

function displaylazrgirlcard(data){
    document.querySelector("#LazyGirlCard").innerHTML=`
        ${ data.map((el)=>{
                return `<div id="smallCard" onclick="girl()">
                          <img src="${el}" alt="err">
                         </div>`
                          }).join(" ")}
                        `
                 }

function girl(){
  window.location.href="./product2.html";
}
// New On The Block
      
     
     let newBlock=[
                    "https://logan.nnnow.com/content/dam/nnnow-project/13-oct-2022/SC_NOTB.jpg",
                    "https://logan.nnnow.com/content/dam/nnnow-project/31-mar-2022/se/SC_NOTB_BigByDefinitionMascara.jpg", 
                    "https://logan.nnnow.com/content/dam/nnnow-project/12-dec-2022/se/HomepageNewontheBlockBanner1659X1020.png",                  
                    "https://logan.nnnow.com/content/dam/nnnow-project/27-nov-2022/se/Smashbox_NOTB.jpg",  
                    "https://logan.nnnow.com/content/dam/nnnow-project/31-oct-2022/ABH_NOTB_RoseMetalsPallete.jpg",            
                    "https://logan.nnnow.com/content/dam/nnnow-project/14-sep-2022/Hudabeauty_NOTB.jpg"
                ]
  
displayNewBlockCard(newBlock);          
function displayNewBlockCard(data){
    document.querySelector("#BlockContainer").innerHTML=`
    ${data.map((el)=>{
        return `<div id="newblocksmallcard" onclick="fun()">
        <img src="${el}" alt="newcard">
        </div>
        `
    }).join(" ")}
    `
}       
   
function fun(){
  window.location.href="./product2.html";
} 



displayC4RADiary(Diaries);
function displayC4RADiary(data){
    document.querySelector(".C4RADiarierContainer").innerHTML=`
        ${ data.map((el)=>{
                return `<div id="smallCard">
                          <img src="${el.Image}" alt="err">
                          <h3>${el.Name}</h3>
                          <p>${el.Description}</p>
                         </div>`
                          }).join(" ")}
                        `
                 }



//adding user structure to local storage to faciliate add to cart functoinality
let userStructure={
  "id": 1,
  "userName": "",
  "profilePic":"https://cloudflare-ipfs.com/ipfs/Qmd3W5DuhgHirLHGVixi6V76LhCkZUz6pnFt5AJBiyvHye/avatar/985.jpg",
  "Address" : "",
  "cartItems": [],
  "orders":[],
  "additionalInfo":[],
  "payment":0
  
}
if(localStorage.getItem("userdata")){}
else{
localStorage.setItem("userdata",JSON.stringify(userStructure));
}