## Sephora clone                                                                                                                                              
Clone of Sephora Website                                                                                                                                                
Sephora Websit is a cosmetic products web application. A one week project for cloning the "https://sephora.nnnow.com" web application.                                                                                  

Deployed link of project
https://sephora-clone-c4ra.netlify.app/
---
---
![2022-12-22](https://user-images.githubusercontent.com/106810850/208999215-29b192e9-53fb-48a4-a8aa-54192e093086.png)

---

**Contributors**

Varun (Team Leader)                                                                                                                                                      
Aman Kumar                                                                                                                                                                                                                                                                                                                                    
Ayushi Bajpai                                                                                                                                                            
Anandhu                                                                                                                                                                  
Hemensan Mahilange




🛠 Tech Stack

Tech stack: HTML CSS Javascript



Challanges we faced                                                                                                                                                      
Merging each other code on Github                                                                                                                                        
Read others code and make changes to it                                                                                                                                  
Exact pixel-perfect cloning of the website                                                                                                                                                                                                                                                                                                
 

API's      👇👇👇                                                                                                                                                      
Users    : https://636f9027f2ed5cb047e01947.mockapi.io/reg_mail                                                                                                          
Products : https://636f9027f2ed5cb047e01947.mockapi.io/Project_2_Products                                                                                                
Cart     : https://639c5a3b16d1763ab1472b90.mockapi.io/cart                                                                                                              
